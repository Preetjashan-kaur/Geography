function validate() {
    //validate username
    var fname1=document.getElementById("first").value;
    var fname2=document.getElementById("first");
    var f_result = /^[A-Za-z]+$/;
    if(f_result.test(fname1)==false){
      fname2.style.border="red solid 3px";
      alert('Name should contain letters only  ');
      //return false;
    }
    var lname1=document.getElementById("last").value;
    var lname2=document.getElementById("last");
    var l_result = /^[A-Za-z]+$/;
    if(l_result.test(lname1)==false){
      lname2.style.border="red solid 3px";
      alert('Name should contain letters only  ');
      //return false;
    }
    //validate email id
    var email1 = document.getElementById("email").value;
    var email2 = document.getElementById("email");
    //var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var re=/(\w\.?)+@[\w\.-]+\.\w{2,4}/;
    if (re.test(email1)==false) {
        email2.style.border = "red solid 3px";
        alert('email address should be in this format : keerthi@abc.com');
        //return false;
    }
    //validate phone number
    var phone1=document.getElementById("phone").value;
    var phone2=document.getElementById("phone");
    var p_res=/^[7-9][0-9]{9}$/;
    if(p_res.test(phone1)==false){
      phone2.style.border = "red solid 3px";
      alert('enter the phone number in this format : [7-9][0-9] and contain 10 digits only');
      //return false;
    }

}
function setCookie(c_name, value, expiredays) {  
    var exdate = new Date();  
     exdate.setDate(exdate.getDate() + expiredays);  
     document.cookie = c_name + "=" + value + ";path=/" + ((expiredays ==null) ? "" : ";expires=" + exdate.toGMTString());  
 }  
 function getCookie(name) {  
     var dc = document.cookie;  
     var prefix = name +"=";  
     var begin = dc.indexOf("; " + prefix);  
     if (begin == -1) {  
         begin = dc.indexOf(prefix);  
         if (begin != 0)return null;  
     } else {  
         begin += 2;  
     }  
     var end = document.cookie.indexOf(";", begin);  
     if (end == -1) {  
         end = dc.length;  
     }  
     return unescape(dc.substring(begin + prefix.length, end));  
 }  

function savename() {  
     setCookie("FirstName", document.getElementById("first").value, 1);  
     setCookie("LastName", document.getElementById("last").value, 1); 
     setCookie("EmailID", document.getElementById("email").value, 1);   
     setCookie("Phone", document.getElementById("phone").value, 1);  
     setCookie("Message", document.getElementById("message").value, 1);  
 }  
 
function submitForm(){
	window.open("../pages/user_info.html");
}

 function getName() {  
     var firstname = getCookie("FirstName");  
     var secondname=    getCookie("LastName");  
     var emailid=    getCookie("EmailID");  
     var phone=    getCookie("Phone");  
     var message1=    getCookie("Message");  
     var currentDate = Date.now();
     alert("time : "+currentDate+"\n\nHello User  \n\nFirst name : "+firstname+"\nSecond name : "+secondname+"\nEmail Address : "+emailid+"\nphone number : "+phone+"\nentered message is : "+message1) ;
 } 

