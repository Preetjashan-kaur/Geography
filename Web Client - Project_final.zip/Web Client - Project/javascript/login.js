var login_username = "admin";
var login_password = "12345";

function authenticate_login() {
  var v1, v2;
  v1 = document.getElementById("uname").value.toLowerCase();
  v2 = document.getElementById("pwd").value;
  if ((v1 == login_username) && (v2 == login_password)) {

    window.open("../pages/second_page.html", "_self", true);
  } else {
    alert('Enter:\nUser Name: admin\nPassword: 12345');
  }
}
